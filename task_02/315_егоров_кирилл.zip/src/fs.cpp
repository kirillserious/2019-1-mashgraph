#include "fs.h"

std::string Fs::dir;